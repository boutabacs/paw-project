
<?php 
  $query = "SELECT * FROM tbladmin WHERE Id = ".$_SESSION['userId']."";
  $rs = $conn->query($query);
  $num = $rs->num_rows;
  $rows = $rs->fetch_assoc();
  $fullName = $rows['firstName']." ".$rows['lastName'];

?>
<nav class="navbar navbar-expand navbar-light bg-gradient-primary topbar mb-4 static-top">
          <!-- Navbar toggler for mobile -->
          <button class="navbar-toggler btn btn-link" type="button" data-toggle="collapse" data-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"><i class="fa fa-bars text-white"></i></span>
          </button>
          <!-- Main nav -->
          <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav app-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">
                  <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="manageDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="fas fa-cog"></i> Manage
                </a>
                <div class="dropdown-menu" aria-labelledby="manageDropdown">
                  <a class="dropdown-item" href="createClass.php">
                    <i class="fas fa-chalkboard mr-2"></i> Create Class
                  </a>
                  <a class="dropdown-item" href="createClassArms.php">
                    <i class="fas fa-code-branch mr-2"></i> Create Class Arms
                  </a>
                  <a class="dropdown-item" href="createClassTeacher.php">
                    <i class="fas fa-chalkboard-teacher mr-2"></i> Create Class Teachers
                  </a>
                  <a class="dropdown-item" href="createStudents.php">
                    <i class="fas fa-user-graduate mr-2"></i> Create Students
                  </a>
                  <a class="dropdown-item" href="createSessionTerm.php">
                    <i class="fas fa-calendar-alt mr-2"></i> Create Session & Term
                  </a>
                  <a class="dropdown-item" href="createUsers.php">
                    <i class="fas fa-users-cog mr-2"></i> Create Users
                  </a>
                </div>
              </li>
            </ul>
          </div>
          <div class="text-white big"><b></b></div>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small search-input" placeholder="What do you want to look for?"
                      aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="img/user-icn.png">
                <span class="ml-2 d-none d-lg-inline text-white small"><b>Welcome <?php echo $fullName;?></b></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php">
                  <i class="fas fa-power-off fa-fw mr-2 text-danger"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
<script>
document.addEventListener('DOMContentLoaded',function(){
  var t=document.getElementById('manageDropdown');
  if(!t)return;
  var p=t.closest('.nav-item.dropdown');
  var m=p?p.querySelector('.dropdown-menu');
  if(!m)return;
  t.addEventListener('click',function(e){
    e.preventDefault();
    var s=m.classList.contains('show');
    m.classList.toggle('show',!s);
    p.classList.toggle('show',!s);
    t.setAttribute('aria-expanded',(!s).toString());
  });
  document.addEventListener('click',function(e){
    if(!p||!m)return;
    if(!p.contains(e.target)){
      m.classList.remove('show');
      p.classList.remove('show');
      t.setAttribute('aria-expanded','false');
    }
  });
});
</script>
