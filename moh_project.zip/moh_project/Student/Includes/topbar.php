<?php 
  $studentQuery = "SELECT tblstudents.firstName, tblstudents.lastName, tblstudents.admissionNumber, tblclass.className, tblclassarms.classArmName
  FROM tblstudents
  INNER JOIN tblclass ON tblclass.Id = tblstudents.classId
  INNER JOIN tblclassarms ON tblclassarms.Id = tblstudents.classArmId
  WHERE tblstudents.Id = ".$_SESSION['studentId']."";
  $rsStudent = $conn->query($studentQuery);
  $student = $rsStudent->fetch_assoc();
  $fullName = $student ? $student['firstName']." ".$student['lastName'] : "Etudiant";
  $classDetails = $student ? $student['className'].' - '.$student['classArmName'] : '';
?>
<nav class="navbar navbar-expand navbar-light bg-gradient-primary topbar mb-4 static-top">
          <!-- Navbar toggler for mobile -->
          <button class="navbar-toggler btn btn-link" type="button" data-toggle="collapse" data-target="#navbarMainS" aria-controls="navbarMainS" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"><i class="fa fa-bars text-white"></i></span>
          </button>
          <!-- Main nav -->
          <div class="collapse navbar-collapse" id="navbarMainS">
            <ul class="navbar-nav app-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">
                  <i class="fas fa-home"></i> Accueil
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="attendance.php">
                  <i class="fas fa-calendar-check"></i> Mes présences
                </a>
              </li>
            </ul>
          </div>
          <div class="text-white big"><b><?php echo $classDetails; ?></b></div>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small search-input" placeholder="What do you want to look for?"
                      aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="../img/user-icn.png">
                <span class="ml-2 d-none d-lg-inline text-white small"><b>Welcome <?php echo $fullName;?></b></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php">
                  <i class="fas fa-power-off fa-fw mr-2 text-danger"></i>
                  Se déconnecter
                </a>
              </div>
            </li>
          </ul>
        </nav>

