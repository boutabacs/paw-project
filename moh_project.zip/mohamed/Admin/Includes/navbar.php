<?php 
  $fullName = '';
  if(isset($_SESSION['userType']) && isset($_SESSION['userId'])){
    if($_SESSION['userType'] === 'Administrator'){
      $rs = $conn->query("SELECT firstName,lastName FROM tbladmin WHERE Id = ".$_SESSION['userId']);
    } elseif($_SESSION['userType'] === 'ClassTeacher'){
      $rs = $conn->query("SELECT firstName,lastName FROM tblclassteacher WHERE Id = ".$_SESSION['userId']);
    } elseif($_SESSION['userType'] === 'Student'){
      $rs = $conn->query("SELECT firstName,lastName FROM tblstudents WHERE Id = ".$_SESSION['userId']);
    }
    if(isset($rs) && $rs && ($rows = $rs->fetch_assoc())){
      $fullName = $rows['firstName']." ".$rows['lastName'];
    } else if(isset($_SESSION['firstName'])){
      $fullName = $_SESSION['firstName'].(isset($_SESSION['lastName']) ? (' '.$_SESSION['lastName']) : '');
    } else {
      $fullName = 'Utilisateur';
    }
  } else {
    $fullName = 'Utilisateur';
  }
  // Déterminer la page active
  $currentPage = basename($_SERVER['PHP_SELF']);
?>
<nav>
  <div class="left">
    <a href="index.php">
      <img src="img/logo/attnlg.jpg" alt="Logo" style="border-radius: 50%; height: 50px; width: 50px;">
    </a>
  </div>
  <div class="right">
    <ul>
      <li><a href="index.php" <?php echo $currentPage == 'index.php' ? 'style="font-weight: bold;"' : ''; ?>>Accueil</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="classesDropdown" data-toggle="dropdown">Classes</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="createClass.php">Créer une Classe</a>
          <a class="dropdown-item" href="createClassArms.php">Créer un Groupe</a>
        </div>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="usersDropdown" data-toggle="dropdown">Utilisateurs</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="manageUsers.php">Gestion des Utilisateurs</a>
          <a class="dropdown-item" href="createStudents.php">Créer un Étudiant</a>
          <a class="dropdown-item" href="createClassTeacher.php">Créer un Professeur</a>
          <a class="dropdown-item" href="createUsers.php">Créer un Administrateur</a>
        </div>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="sessionDropdown" data-toggle="dropdown">Session</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="createSessionTerm.php">Créer Session & Terme</a>
        </div>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="systemDropdown" data-toggle="dropdown">Système</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="systemSettings.php">Paramètres Système</a>
          <a class="dropdown-item" href="viewLogs.php">Logs et Audit</a>
          <a class="dropdown-item" href="importExport.php">Import/Export</a>
          <a class="dropdown-item" href="globalStatistics.php">Statistiques Globales</a>
        </div>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="userDropdown" data-toggle="dropdown"><?php echo $fullName; ?></a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="logout.php">Déconnexion</a>
        </div>
      </li>
    </ul>
  </div>
</nav>

