// Script pour gérer les dropdowns de la navbar avec hover et click
$(document).ready(function() {
    // Gérer les dropdowns au click (pour mobile)
    $('.dropdown-toggle').on('click', function(e) {
        e.preventDefault();
        var $dropdown = $(this).closest('.dropdown');
        
        // Fermer tous les autres dropdowns
        $('.dropdown').not($dropdown).removeClass('show');
        
        // Toggle le dropdown actuel
        $dropdown.toggleClass('show');
    });
    
    // Fermer les dropdowns quand on clique ailleurs
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.dropdown').length) {
            $('.dropdown').removeClass('show');
        }
    });
    
    // Empêcher la fermeture quand on clique dans le dropdown
    $('.dropdown-menu').on('click', function(e) {
        e.stopPropagation();
    });
    
    // S'assurer que les dropdowns sont visibles au hover
    $('.dropdown').hover(
        function() {
            $(this).addClass('show');
        },
        function() {
            // Ne pas fermer immédiatement, laisser le CSS gérer
            // $(this).removeClass('show');
        }
    );
});

