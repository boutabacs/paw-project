<?php 
  $query = "SELECT * FROM tblclassteacher WHERE Id = ".$_SESSION['userId']."";
  $rs = $conn->query($query);
  $rows = $rs->fetch_assoc();
  $fullName = $rows['firstName']." ".$rows['lastName'];
  
  // Compter les notifications non lues
  $notifQuery = "SELECT COUNT(*) as count FROM tblnotifications WHERE userId = '".$_SESSION['userId']."' AND userType = 'teacher' AND isRead = 0";
  $notifRs = $conn->query($notifQuery);
  $notifRow = $notifRs->fetch_assoc();
  $notifCount = $notifRow['count'];
  
  // Déterminer la page active
  $currentPage = basename($_SERVER['PHP_SELF']);
?>
<nav>
  <div class="left">
    <a href="index.php">
      <img src="img/logo/attnlg.jpg" alt="Logo" style="border-radius: 50%; height: 50px; width: 50px;">
    </a>
  </div>
  <div class="right">
    <ul>
      <li><a href="index.php" <?php echo $currentPage == 'index.php' ? 'style="font-weight: bold;"' : ''; ?>>Accueil</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="sessionsDropdown" data-toggle="dropdown">Séances</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="manageSessions.php">Gérer les Séances</a>
        </div>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="attendanceDropdown" data-toggle="dropdown">Présences</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="takeAttendance.php">Prendre les Présences</a>
          <a class="dropdown-item" href="viewAttendance.php">Voir les Présences de la Classe</a>
          <a class="dropdown-item" href="viewStudentAttendance.php">Voir les Présences d'un Étudiant</a>
          <a class="dropdown-item" href="downloadRecord.php">Rapport du Jour (xls)</a>
          <a class="dropdown-item" href="exportPage.php">Exporter les Présences</a>
        </div>
      </li>
      <li><a href="viewJustifications.php" <?php echo $currentPage == 'viewJustifications.php' ? 'style="font-weight: bold;"' : ''; ?>>Justificatifs</a></li>
      <li><a href="statistics.php" <?php echo $currentPage == 'statistics.php' ? 'style="font-weight: bold;"' : ''; ?>>Statistiques</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="notifDropdown" data-toggle="dropdown">
          Notifications
          <?php if($notifCount > 0): ?>
            <span class="badge" style="background: #dc3545; color: white; border-radius: 50%; padding: 2px 6px; font-size: 11px; margin-left: 5px;"><?php echo $notifCount; ?></span>
          <?php endif; ?>
        </a>
        <div class="dropdown-menu dropdown-menu-right" style="max-height: 400px; overflow-y: auto; min-width: 300px;">
          <h6 class="dropdown-header">Notifications</h6>
          <?php
            $notifListQuery = "SELECT * FROM tblnotifications WHERE userId = '".$_SESSION['userId']."' AND userType = 'teacher' ORDER BY dateCreated DESC LIMIT 10";
            $notifListRs = $conn->query($notifListQuery);
            if($notifListRs->num_rows > 0):
              while($notif = $notifListRs->fetch_assoc()):
          ?>
          <a class="dropdown-item" href="<?php echo $notif['link'] ? $notif['link'] : '#'; ?>" style="padding: 10px 15px; white-space: normal; color: #223656 !important;">
            <div style="font-size: 11px; color: #666666 !important; margin-bottom: 4px;"><?php echo date('d/m/Y H:i', strtotime($notif['dateCreated'])); ?></div>
            <div style="<?php echo $notif['isRead'] == 0 ? 'font-weight: bold;' : ''; ?> color: #223656 !important;"><?php echo $notif['title']; ?></div>
          </a>
          <?php
              endwhile;
            else:
          ?>
          <div class="dropdown-item" style="text-align: center; color: #666666 !important; background-color: #ffffff !important;">Aucune notification</div>
          <?php endif; ?>
        </div>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" id="userDropdown" data-toggle="dropdown"><?php echo $fullName; ?></a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="logout.php">Déconnexion</a>
        </div>
      </li>
    </ul>
  </div>
</nav>

